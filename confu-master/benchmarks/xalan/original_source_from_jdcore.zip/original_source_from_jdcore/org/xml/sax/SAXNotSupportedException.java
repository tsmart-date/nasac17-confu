package org.xml.sax;

public class SAXNotSupportedException
  extends SAXException
{
  static final long serialVersionUID = -1422818934641823846L;
  
  public SAXNotSupportedException() {}
  
  public SAXNotSupportedException(String paramString)
  {
    super(paramString);
  }
}
