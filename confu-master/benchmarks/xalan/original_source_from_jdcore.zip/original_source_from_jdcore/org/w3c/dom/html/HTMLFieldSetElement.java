package org.w3c.dom.html;

public abstract interface HTMLFieldSetElement
  extends HTMLElement
{
  public abstract HTMLFormElement getForm();
}
