package org.w3c.dom.html;

public abstract interface HTMLTitleElement
  extends HTMLElement
{
  public abstract String getText();
  
  public abstract void setText(String paramString);
}
