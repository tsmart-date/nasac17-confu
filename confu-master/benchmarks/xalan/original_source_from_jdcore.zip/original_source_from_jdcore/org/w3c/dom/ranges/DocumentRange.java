package org.w3c.dom.ranges;

public abstract interface DocumentRange
{
  public abstract Range createRange();
}
