package org.w3c.dom.html;

public abstract interface HTMLHtmlElement
  extends HTMLElement
{
  public abstract String getVersion();
  
  public abstract void setVersion(String paramString);
}
