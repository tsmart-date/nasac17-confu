package org.w3c.dom;

public abstract interface EntityReference
  extends Node
{}
