package org.w3c.dom.stylesheets;

public abstract interface LinkStyle
{
  public abstract StyleSheet getSheet();
}
