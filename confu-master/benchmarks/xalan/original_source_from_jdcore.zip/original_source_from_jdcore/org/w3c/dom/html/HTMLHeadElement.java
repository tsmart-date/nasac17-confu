package org.w3c.dom.html;

public abstract interface HTMLHeadElement
  extends HTMLElement
{
  public abstract String getProfile();
  
  public abstract void setProfile(String paramString);
}
