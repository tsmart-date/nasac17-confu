package org.w3c.dom.stylesheets;

public abstract interface StyleSheetList
{
  public abstract int getLength();
  
  public abstract StyleSheet item(int paramInt);
}
