package org.w3c.dom.ls;

public abstract interface LSResourceResolver
{
  public abstract LSInput resolveResource(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
}
