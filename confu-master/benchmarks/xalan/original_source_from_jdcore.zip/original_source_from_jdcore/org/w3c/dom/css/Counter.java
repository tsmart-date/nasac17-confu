package org.w3c.dom.css;

public abstract interface Counter
{
  public abstract String getIdentifier();
  
  public abstract String getListStyle();
  
  public abstract String getSeparator();
}
