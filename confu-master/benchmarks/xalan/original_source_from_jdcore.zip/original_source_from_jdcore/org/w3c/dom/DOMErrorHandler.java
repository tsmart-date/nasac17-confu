package org.w3c.dom;

public abstract interface DOMErrorHandler
{
  public abstract boolean handleError(DOMError paramDOMError);
}
