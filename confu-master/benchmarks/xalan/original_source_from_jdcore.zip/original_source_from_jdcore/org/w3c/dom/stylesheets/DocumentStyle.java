package org.w3c.dom.stylesheets;

public abstract interface DocumentStyle
{
  public abstract StyleSheetList getStyleSheets();
}
