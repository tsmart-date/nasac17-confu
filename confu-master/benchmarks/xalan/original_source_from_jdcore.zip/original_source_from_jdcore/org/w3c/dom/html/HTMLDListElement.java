package org.w3c.dom.html;

public abstract interface HTMLDListElement
  extends HTMLElement
{
  public abstract boolean getCompact();
  
  public abstract void setCompact(boolean paramBoolean);
}
