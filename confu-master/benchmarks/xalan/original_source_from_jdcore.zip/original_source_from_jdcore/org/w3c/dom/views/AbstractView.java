package org.w3c.dom.views;

public abstract interface AbstractView
{
  public abstract DocumentView getDocument();
}
