package org.w3c.dom.html;

public abstract interface HTMLBaseElement
  extends HTMLElement
{
  public abstract String getHref();
  
  public abstract void setHref(String paramString);
  
  public abstract String getTarget();
  
  public abstract void setTarget(String paramString);
}
