package org.w3c.dom.css;

public abstract interface ElementCSSInlineStyle
{
  public abstract CSSStyleDeclaration getStyle();
}
