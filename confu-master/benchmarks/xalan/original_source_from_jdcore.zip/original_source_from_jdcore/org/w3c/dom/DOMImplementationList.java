package org.w3c.dom;

public abstract interface DOMImplementationList
{
  public abstract DOMImplementation item(int paramInt);
  
  public abstract int getLength();
}
