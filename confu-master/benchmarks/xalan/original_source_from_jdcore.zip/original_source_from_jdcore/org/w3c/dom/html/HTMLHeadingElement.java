package org.w3c.dom.html;

public abstract interface HTMLHeadingElement
  extends HTMLElement
{
  public abstract String getAlign();
  
  public abstract void setAlign(String paramString);
}
