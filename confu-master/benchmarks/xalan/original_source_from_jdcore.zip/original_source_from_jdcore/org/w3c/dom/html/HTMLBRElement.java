package org.w3c.dom.html;

public abstract interface HTMLBRElement
  extends HTMLElement
{
  public abstract String getClear();
  
  public abstract void setClear(String paramString);
}
