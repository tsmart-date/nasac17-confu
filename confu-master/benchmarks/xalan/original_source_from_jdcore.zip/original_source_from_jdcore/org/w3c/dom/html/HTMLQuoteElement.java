package org.w3c.dom.html;

public abstract interface HTMLQuoteElement
  extends HTMLElement
{
  public abstract String getCite();
  
  public abstract void setCite(String paramString);
}
