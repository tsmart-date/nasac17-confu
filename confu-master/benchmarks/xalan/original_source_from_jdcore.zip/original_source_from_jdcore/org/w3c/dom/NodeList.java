package org.w3c.dom;

public abstract interface NodeList
{
  public abstract Node item(int paramInt);
  
  public abstract int getLength();
}
