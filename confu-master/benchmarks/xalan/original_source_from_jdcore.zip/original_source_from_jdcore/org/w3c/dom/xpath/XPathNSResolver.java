package org.w3c.dom.xpath;

public abstract interface XPathNSResolver
{
  public abstract String lookupNamespaceURI(String paramString);
}
