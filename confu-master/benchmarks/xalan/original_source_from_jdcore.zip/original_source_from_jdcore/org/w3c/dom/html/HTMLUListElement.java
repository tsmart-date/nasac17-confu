package org.w3c.dom.html;

public abstract interface HTMLUListElement
  extends HTMLElement
{
  public abstract boolean getCompact();
  
  public abstract void setCompact(boolean paramBoolean);
  
  public abstract String getType();
  
  public abstract void setType(String paramString);
}
