package org.w3c.dom.events;

public abstract interface EventListener
{
  public abstract void handleEvent(Event paramEvent);
}
