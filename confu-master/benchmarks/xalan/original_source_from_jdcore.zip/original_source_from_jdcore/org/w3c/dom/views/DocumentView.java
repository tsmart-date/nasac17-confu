package org.w3c.dom.views;

public abstract interface DocumentView
{
  public abstract AbstractView getDefaultView();
}
