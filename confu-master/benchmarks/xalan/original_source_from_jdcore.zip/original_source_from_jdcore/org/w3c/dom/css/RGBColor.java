package org.w3c.dom.css;

public abstract interface RGBColor
{
  public abstract CSSPrimitiveValue getRed();
  
  public abstract CSSPrimitiveValue getGreen();
  
  public abstract CSSPrimitiveValue getBlue();
}
