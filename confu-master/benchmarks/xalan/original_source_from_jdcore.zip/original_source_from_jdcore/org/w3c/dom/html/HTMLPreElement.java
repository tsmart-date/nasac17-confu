package org.w3c.dom.html;

public abstract interface HTMLPreElement
  extends HTMLElement
{
  public abstract int getWidth();
  
  public abstract void setWidth(int paramInt);
}
