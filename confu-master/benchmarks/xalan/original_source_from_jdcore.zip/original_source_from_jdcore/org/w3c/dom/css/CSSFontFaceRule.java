package org.w3c.dom.css;

public abstract interface CSSFontFaceRule
  extends CSSRule
{
  public abstract CSSStyleDeclaration getStyle();
}
