package org.w3c.dom;

public abstract interface DOMStringList
{
  public abstract String item(int paramInt);
  
  public abstract int getLength();
  
  public abstract boolean contains(String paramString);
}
