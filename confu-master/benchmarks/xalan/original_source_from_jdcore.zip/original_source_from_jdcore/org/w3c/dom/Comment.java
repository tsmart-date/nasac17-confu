package org.w3c.dom;

public abstract interface Comment
  extends CharacterData
{}
