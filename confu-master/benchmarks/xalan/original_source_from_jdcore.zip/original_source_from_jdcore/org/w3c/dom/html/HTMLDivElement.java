package org.w3c.dom.html;

public abstract interface HTMLDivElement
  extends HTMLElement
{
  public abstract String getAlign();
  
  public abstract void setAlign(String paramString);
}
