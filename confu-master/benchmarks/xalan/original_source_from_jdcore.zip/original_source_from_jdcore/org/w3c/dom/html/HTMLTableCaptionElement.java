package org.w3c.dom.html;

public abstract interface HTMLTableCaptionElement
  extends HTMLElement
{
  public abstract String getAlign();
  
  public abstract void setAlign(String paramString);
}
