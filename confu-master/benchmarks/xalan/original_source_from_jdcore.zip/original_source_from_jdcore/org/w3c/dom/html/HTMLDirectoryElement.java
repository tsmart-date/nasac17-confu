package org.w3c.dom.html;

public abstract interface HTMLDirectoryElement
  extends HTMLElement
{
  public abstract boolean getCompact();
  
  public abstract void setCompact(boolean paramBoolean);
}
