package org.w3c.dom.html;

public abstract interface HTMLModElement
  extends HTMLElement
{
  public abstract String getCite();
  
  public abstract void setCite(String paramString);
  
  public abstract String getDateTime();
  
  public abstract void setDateTime(String paramString);
}
