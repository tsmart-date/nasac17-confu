package org.w3c.dom;

public abstract interface DocumentFragment
  extends Node
{}
