package org.apache.xml.utils;















public class WrongParserException
  extends RuntimeException
{
  static final long serialVersionUID = 6481643018533043846L;
  














  public WrongParserException(String message)
  {
    super(message);
  }
}
