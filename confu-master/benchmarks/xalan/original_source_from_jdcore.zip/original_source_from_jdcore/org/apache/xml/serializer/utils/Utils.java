package org.apache.xml.serializer.utils;


































public final class Utils
{
  public static final Messages messages = new Messages(SerializerMessages.class.getName());
  
  public Utils() {}
}
