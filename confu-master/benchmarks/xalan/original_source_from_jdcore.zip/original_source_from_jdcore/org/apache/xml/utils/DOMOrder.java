package org.apache.xml.utils;

/**
 * @deprecated
 */
public abstract interface DOMOrder
{
  public abstract int getUid();
}
