package org.apache.xml.res;

public class XMLErrorResources_en
  extends XMLErrorResources
{
  public XMLErrorResources_en() {}
}
