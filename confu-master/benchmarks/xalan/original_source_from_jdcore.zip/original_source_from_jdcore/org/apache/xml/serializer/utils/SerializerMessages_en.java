package org.apache.xml.serializer.utils;

public final class SerializerMessages_en
  extends SerializerMessages
{
  public SerializerMessages_en() {}
}
