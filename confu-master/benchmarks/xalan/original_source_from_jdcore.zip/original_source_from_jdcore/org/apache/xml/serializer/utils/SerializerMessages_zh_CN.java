package org.apache.xml.serializer.utils;

public class SerializerMessages_zh_CN
  extends SerializerMessages_zh
{
  public SerializerMessages_zh_CN() {}
}
