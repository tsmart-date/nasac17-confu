package org.apache.wml;

public abstract interface WMLTrElement
  extends WMLElement
{}
