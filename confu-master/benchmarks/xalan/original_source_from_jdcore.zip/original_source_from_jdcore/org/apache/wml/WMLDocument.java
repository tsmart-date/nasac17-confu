package org.apache.wml;

import org.w3c.dom.Document;

public abstract interface WMLDocument
  extends Document
{}
