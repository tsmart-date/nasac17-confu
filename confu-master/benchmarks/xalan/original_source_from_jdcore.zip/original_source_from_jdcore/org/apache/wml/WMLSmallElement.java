package org.apache.wml;

public abstract interface WMLSmallElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}
