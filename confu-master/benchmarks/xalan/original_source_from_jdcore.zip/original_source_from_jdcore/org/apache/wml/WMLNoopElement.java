package org.apache.wml;

public abstract interface WMLNoopElement
  extends WMLElement
{}
