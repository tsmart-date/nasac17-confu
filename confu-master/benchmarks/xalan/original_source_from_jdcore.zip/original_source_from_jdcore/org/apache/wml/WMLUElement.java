package org.apache.wml;

public abstract interface WMLUElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}
