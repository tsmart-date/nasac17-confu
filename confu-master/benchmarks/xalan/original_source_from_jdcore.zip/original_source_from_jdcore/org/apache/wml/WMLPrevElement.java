package org.apache.wml;

public abstract interface WMLPrevElement
  extends WMLElement
{}
