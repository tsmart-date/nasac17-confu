package org.apache.wml;

import org.w3c.dom.DOMImplementation;

public abstract interface WMLDOMImplementation
  extends DOMImplementation
{}
