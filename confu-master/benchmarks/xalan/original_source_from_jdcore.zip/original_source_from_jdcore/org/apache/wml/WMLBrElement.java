package org.apache.wml;

public abstract interface WMLBrElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}
