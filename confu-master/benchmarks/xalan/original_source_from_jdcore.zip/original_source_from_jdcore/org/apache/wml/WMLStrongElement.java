package org.apache.wml;

public abstract interface WMLStrongElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}
