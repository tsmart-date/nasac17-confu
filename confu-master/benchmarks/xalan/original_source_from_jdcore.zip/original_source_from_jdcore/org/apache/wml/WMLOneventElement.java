package org.apache.wml;

public abstract interface WMLOneventElement
  extends WMLElement
{
  public abstract void setType(String paramString);
  
  public abstract String getType();
}
