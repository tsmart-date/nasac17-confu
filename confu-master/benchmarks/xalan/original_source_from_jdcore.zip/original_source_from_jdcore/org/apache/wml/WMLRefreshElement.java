package org.apache.wml;

public abstract interface WMLRefreshElement
  extends WMLElement
{}
