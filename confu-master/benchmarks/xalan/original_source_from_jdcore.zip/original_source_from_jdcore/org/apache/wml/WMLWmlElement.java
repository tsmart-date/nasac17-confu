package org.apache.wml;

public abstract interface WMLWmlElement
  extends WMLElement
{
  public abstract void setXmlLang(String paramString);
  
  public abstract String getXmlLang();
}
