package javax.xml.transform;

public abstract interface Source
{
  public abstract void setSystemId(String paramString);
  
  public abstract String getSystemId();
}
