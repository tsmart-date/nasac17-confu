package org.w3c.dom.html;

public abstract interface HTMLFontElement
  extends HTMLElement
{
  public abstract String getColor();
  
  public abstract void setColor(String paramString);
  
  public abstract String getFace();
  
  public abstract void setFace(String paramString);
  
  public abstract String getSize();
  
  public abstract void setSize(String paramString);
}
