package org.apache.xerces.impl.dv.xs;

public class SchemaDateTimeException
  extends RuntimeException
{
  static final long serialVersionUID = -8520832235337769040L;
  
  public SchemaDateTimeException() {}
  
  public SchemaDateTimeException(String paramString)
  {
    super(paramString);
  }
}
