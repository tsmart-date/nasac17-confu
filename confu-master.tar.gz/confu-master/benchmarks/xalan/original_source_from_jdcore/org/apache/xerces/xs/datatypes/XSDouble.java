package org.apache.xerces.xs.datatypes;

public abstract interface XSDouble
{
  public abstract double getValue();
}
