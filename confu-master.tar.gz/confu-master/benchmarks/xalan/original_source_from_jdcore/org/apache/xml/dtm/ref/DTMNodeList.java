package org.apache.xml.dtm.ref;

import org.apache.xml.dtm.DTM;
import org.apache.xml.dtm.DTMIterator;
import org.w3c.dom.Node;


























































public class DTMNodeList
  extends DTMNodeListBase
{
  private DTMIterator m_iter;
  
  private DTMNodeList() {}
  
  public DTMNodeList(DTMIterator dtmIterator)
  {
    if (dtmIterator != null) {
      int pos = dtmIterator.getCurrentPos();
      try {
        m_iter = dtmIterator.cloneWithReset();
      } catch (CloneNotSupportedException cnse) {
        m_iter = dtmIterator;
      }
      m_iter.setShouldCacheNodes(true);
      m_iter.runTo(-1);
      m_iter.setCurrentPos(pos);
    }
  }
  




  public DTMIterator getDTMIterator()
  {
    return m_iter;
  }
  












  public Node item(int index)
  {
    if (m_iter != null) {
      int handle = m_iter.item(index);
      if (handle == -1) {
        return null;
      }
      return m_iter.getDTM(handle).getNode(handle);
    }
    return null;
  }
  




  public int getLength()
  {
    return m_iter != null ? m_iter.getLength() : 0;
  }
}
