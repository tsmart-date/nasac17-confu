package org.apache.xml.utils.res;

















public class XResources_zh_CN
  extends XResourceBundle
{
  public XResources_zh_CN() {}
  















  public Object[][] getContents()
  {
    return new Object[][] { { "ui_language", "zh" }, { "help_language", "zh" }, { "language", "zh" }, { "alphabet", new CharArrayWrapper(new char[] { 65313, 65314, 65315, 65316, 65317, 65318, 65319, 65320, 65321, 65322, 65323, 65324, 65325, 65326, 65327, 65328, 65329, 65330, 65331, 65332, 65333, 65334, 65335, 65336, 65337, 65338 }) }, { "tradAlphabet", new CharArrayWrapper(new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' }) }, { "orientation", "LeftToRight" }, { "numbering", "multiplicative-additive" }, { "multiplierOrder", "follows" }, { "numberGroups", new IntArrayWrapper(new int[] { 1 }) }, { "zero", new CharArrayWrapper(new char[] { 38646 }) }, { "multiplier", new LongArrayWrapper(new long[] { 100000000L, 10000L, 1000L, 100L, 10L }) }, { "multiplierChar", new CharArrayWrapper(new char[] { '亿', '万', '千', '百', '十' }) }, { "digits", new CharArrayWrapper(new char[] { '一', '二', '三', '四', '五', '六', '七', '八', '九' }) }, { "tables", new StringArrayWrapper(new String[] { "digits" }) } };
  }
}
