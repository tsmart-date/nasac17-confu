package org.apache.xalan.xsltc.cmdline.getopt;











public class GetOptsException
  extends Exception
{
  static final long serialVersionUID = 8736874967183039804L;
  










  public GetOptsException(String msg)
  {
    super(msg);
  }
}
