package org.apache.xalan.serialize;

/**
 * @deprecated
 */
public abstract interface DOMSerializer
  extends org.apache.xml.serializer.DOMSerializer
{}
