package org.apache.xalan.xsltc;

public abstract interface DOMCache
{
  public abstract DOM retrieveDocument(String paramString1, String paramString2, Translet paramTranslet);
}
