package org.apache.bcel.verifier.exc;

































































public class StaticCodeInstructionConstraintException
  extends StaticCodeConstraintException
{
  public StaticCodeInstructionConstraintException(String message)
  {
    super(message);
  }
}
