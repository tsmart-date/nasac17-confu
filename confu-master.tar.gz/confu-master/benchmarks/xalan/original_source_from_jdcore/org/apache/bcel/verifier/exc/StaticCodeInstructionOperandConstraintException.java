package org.apache.bcel.verifier.exc;

































































public class StaticCodeInstructionOperandConstraintException
  extends StaticCodeConstraintException
{
  public StaticCodeInstructionOperandConstraintException(String message)
  {
    super(message);
  }
}
